//Global object - that are available thoughout your application without importing

//console.log(global)

//console.log(process)

//console.log(console)

// console.log(setTimeout)

//console.log(module)

console.log(__dirname)

console.log(__filename)

